
public enum Event {
	
	Menu,
	CharacterSelection,
	Help,
	Game,
	Death,
	Help2,
	Win,
	Request,
	
}
