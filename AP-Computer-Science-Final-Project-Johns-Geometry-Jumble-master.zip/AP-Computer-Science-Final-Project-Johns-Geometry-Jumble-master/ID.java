
public enum ID {
	
	John,
	Albert,
	Gon,
	Enemy,
	Boss,
	BadBullet,
	GoodBullet, 
	Shield,
	MedKit,
	Star,
}
